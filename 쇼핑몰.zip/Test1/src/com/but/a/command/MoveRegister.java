package com.but.a.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MoveRegister implements CommandHandler {
	public static final String VIEW = "/WEB-INF/view/neha/register.jsp";
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return VIEW;
	}

}
