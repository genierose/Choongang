package com.but.a.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MoveCart implements CommandHandler{
	public static final String VIEW = "/WEB-INF/view/neha/cart.jsp";
	
	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		return VIEW;
	}
}
