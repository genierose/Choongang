package com.but.a.controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.but.a.command.*;

/**
 * Servlet implementation class ControllerUsingURI
 */
public class ControllerUsingURI extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, CommandHandler> commandHandlerMap = new HashMap<String, CommandHandler>();
	public void init() throws ServletException {
		commandHandlerMap.put("/about-us.do", new MoveAboutUs());
		commandHandlerMap.put("/blog-details.do", new MoveBlogDetails());
		commandHandlerMap.put("/blog.do", new MoveBlog());
		commandHandlerMap.put("/cart.do", new MoveCart());
		commandHandlerMap.put("/checkout.do", new MoveCheckOut());
		commandHandlerMap.put("/contact.do", new MoveContact());
		commandHandlerMap.put("/index.do", new MoveIndex());
		commandHandlerMap.put("/login.do", new MoveLogin());
		commandHandlerMap.put("/product-details.do", new MoveProductDetails());
		commandHandlerMap.put("/register.do", new MoveRegister());
		commandHandlerMap.put("/shop-grid-view-5-col.do", new MoveShopGridView5Col());
		commandHandlerMap.put("/wishlist.do", new MoveWishlist());
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerUsingURI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		process(request, response);
	}
	
	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

		String viewPage = null;
		CommandHandler cmd = null;
		
		String command = request.getRequestURI();
		command = command.substring(request.getContextPath().length());
		
		//이건 값 매칭을 .. 키값이 두개가 있으면 둘중 아무거나해도 매칭이 되는건가?
		cmd = commandHandlerMap.get(command);		
		
		viewPage = cmd.process(request, response);
		
		if(viewPage != null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher(viewPage);
			dispatcher.forward(request, response);
		}
	}

}
